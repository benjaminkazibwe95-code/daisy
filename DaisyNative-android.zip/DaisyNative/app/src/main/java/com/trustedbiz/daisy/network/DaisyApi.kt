package com.trustedbiz.daisy.network

import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** One line of the /ask NDJSON stream, already parsed. */
sealed class AskEvent {
    data class Status(val message: String) : AskEvent()
    data class Final(
        val answer: String,
        val sources: List<String>,
        val usedWebSearch: Boolean,
        val memoryFact: String?
    ) : AskEvent()
    data class Error(val message: String) : AskEvent()
}

/**
 * Talks directly to the existing Flask backend — no WebView involved.
 * The base URL points at the same Render deployment the web app and the
 * old TWA both used, so every account-free feature (corrections cache,
 * shared projects) keeps working unchanged.
 */
class DaisyApi(private val baseUrl: String = "https://daisy-qg1c.onrender.com") {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS) // streaming — no read timeout
        .build()

    /**
     * Streams status + final events for one question. Mirrors the exact
     * JSON shape the web frontend already relies on: {"question","learned",
     * "history","instructions","image","memory","web_search_enabled"}.
     */
    fun ask(
        question: String,
        history: List<Triple<String, String, String>>, // user, daisy, topic
        instructions: String,
        memoryFacts: List<String>,
        webSearchEnabled: Boolean,
        imageBase64: String? = null,
        imageMediaType: String? = null
    ): Flow<AskEvent> = callbackFlow {
        val historyArr = JSONArray().apply {
            history.forEach { (u, d, t) ->
                put(JSONObject().apply {
                    put("user", u); put("daisy", d); put("topic", t)
                })
            }
        }
        val memoryArr = JSONArray(memoryFacts)

        val body = JSONObject().apply {
            put("question", question)
            put("learned", JSONObject())
            put("history", historyArr)
            put("instructions", instructions)
            put("memory", memoryArr)
            put("web_search_enabled", webSearchEnabled)
            if (imageBase64 != null && imageMediaType != null) {
                put("image", JSONObject().apply {
                    put("media_type", imageMediaType)
                    put("data", imageBase64)
                })
            }
        }.toString().toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("$baseUrl/ask")
            .post(body)
            .build()

        val call = client.newCall(request)
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                trySend(AskEvent.Error(e.message ?: "Couldn't reach Daisy — check your connection."))
                close()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    if (!resp.isSuccessful) {
                        trySend(AskEvent.Error("Server error (${resp.code}). Try again."))
                        close()
                        return
                    }
                    val source = resp.body?.source()
                    try {
                        while (source != null && !source.exhausted()) {
                            val line = source.readUtf8Line() ?: break
                            if (line.isBlank()) continue
                            parseLine(line)?.let { trySend(it) }
                        }
                    } catch (e: IOException) {
                        trySend(AskEvent.Error("Connection dropped — try again."))
                    } finally {
                        close()
                    }
                }
            }
        })

        awaitClose { call.cancel() }
    }

    private fun parseLine(line: String): AskEvent? {
        return try {
            val obj = JSONObject(line)
            when (obj.optString("event")) {
                "status" -> AskEvent.Status(obj.optString("status", "thinking"))
                "final" -> {
                    val sourcesArr = obj.optJSONArray("sources")
                    val sources = sourcesArr?.let { arr -> (0 until arr.length()).map { arr.getString(it) } } ?: emptyList()
                    AskEvent.Final(
                        answer = obj.optString("answer", ""),
                        sources = sources,
                        usedWebSearch = obj.optBoolean("used_web_search", false),
                        memoryFact = obj.optString("memory_fact", null).takeIf { !it.isNullOrBlank() }
                    )
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }
}
