package com.trustedbiz.daisy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.trustedbiz.daisy.ui.chat.ChatScreen
import com.trustedbiz.daisy.ui.chat.ChatViewModel
import com.trustedbiz.daisy.ui.settings.SettingsScreen
import com.trustedbiz.daisy.ui.settings.SettingsViewModel
import com.trustedbiz.daisy.ui.theme.DaisyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DaisyTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DaisyApp()
                }
            }
        }
    }
}

@Composable
fun DaisyApp() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "chat") {
        composable("chat") {
            val chatViewModel: ChatViewModel = viewModel()
            ChatScreen(
                viewModel = chatViewModel,
                onOpenSettings = { navController.navigate("settings") }
            )
        }
        composable("settings") {
            val settingsViewModel: SettingsViewModel = viewModel()
            SettingsScreen(
                viewModel = settingsViewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
