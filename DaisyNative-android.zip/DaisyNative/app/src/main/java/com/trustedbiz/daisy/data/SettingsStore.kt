package com.trustedbiz.daisy.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray

private val Context.dataStore by preferencesDataStore(name = "daisy_settings")

/**
 * Local persistence for everything the web app used to keep in localStorage:
 * the custom persona instructions, the web-search toggle, and the rolling
 * list of remembered facts. All three are sent back to the backend with
 * every /ask call, since the server itself is stateless per-request.
 */
class SettingsStore(private val context: Context) {

    private object Keys {
        val INSTRUCTIONS = stringPreferencesKey("instructions")
        val WEB_SEARCH = booleanPreferencesKey("web_search_enabled")
        val MEMORY = stringPreferencesKey("memory_facts_json")
    }

    val instructions: Flow<String> = context.dataStore.data.map { it[Keys.INSTRUCTIONS] ?: "" }
    val webSearchEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.WEB_SEARCH] ?: true }
    val memoryFacts: Flow<List<String>> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.MEMORY] ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getString(it) }
    }

    suspend fun setInstructions(value: String) {
        context.dataStore.edit { it[Keys.INSTRUCTIONS] = value }
    }

    suspend fun setWebSearchEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.WEB_SEARCH] = value }
    }

    suspend fun addMemoryFact(fact: String) {
        context.dataStore.edit { prefs ->
            val raw = prefs[Keys.MEMORY] ?: "[]"
            val arr = JSONArray(raw)
            val list = (0 until arr.length()).map { arr.getString(it) }.toMutableList()
            list.add(fact)
            // Cap at 40, same as the web client, so it can't grow forever.
            val capped = if (list.size > 40) list.takeLast(40) else list
            prefs[Keys.MEMORY] = JSONArray(capped).toString()
        }
    }
}
