package com.trustedbiz.daisy.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.trustedbiz.daisy.data.ChatMessage
import com.trustedbiz.daisy.data.Role
import com.trustedbiz.daisy.data.SettingsStore
import com.trustedbiz.daisy.network.AskEvent
import com.trustedbiz.daisy.network.DaisyApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val isSending: Boolean = false,
    val statusLabel: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val api = DaisyApi()
    private val settings = SettingsStore(application)

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    // {user, daisy, topic} turns sent back to the backend as conversational memory.
    private val turnHistory = mutableListOf<Triple<String, String, String>>()

    fun onInputChange(value: String) {
        _uiState.value = _uiState.value.copy(input = value)
    }

    fun send() {
        val question = _uiState.value.input.trim()
        if (question.isEmpty() || _uiState.value.isSending) return

        val userMsg = ChatMessage(id = UUID.randomUUID().toString(), role = Role.USER, text = question)
        val daisyPlaceholder = ChatMessage(id = UUID.randomUUID().toString(), role = Role.DAISY, text = "", isStreaming = true)

        _uiState.value = _uiState.value.copy(
            messages = _uiState.value.messages + userMsg + daisyPlaceholder,
            input = "",
            isSending = true,
            statusLabel = "Thinking…"
        )

        viewModelScope.launch {
            val instructions = settings.instructions.first()
            val memory = settings.memoryFacts.first()
            val webSearchEnabled = settings.webSearchEnabled.first()

            var finalAnswer = ""
            api.ask(
                question = question,
                history = turnHistory.toList(),
                instructions = instructions,
                memoryFacts = memory,
                webSearchEnabled = webSearchEnabled
            ).collectLatest { event ->
                when (event) {
                    is AskEvent.Status -> {
                        _uiState.value = _uiState.value.copy(
                            statusLabel = when (event.message) {
                                "searching" -> "Searching the web…"
                                else -> "Thinking…"
                            }
                        )
                    }
                    is AskEvent.Final -> {
                        finalAnswer = event.answer
                        turnHistory.add(Triple(question, event.answer, ""))
                        if (turnHistory.size > 20) turnHistory.removeAt(0)
                        event.memoryFact?.let { settings.addMemoryFact(it) }

                        _uiState.value = _uiState.value.copy(
                            messages = _uiState.value.messages.map {
                                if (it.id == daisyPlaceholder.id)
                                    it.copy(text = finalAnswer, sources = event.sources, isStreaming = false)
                                else it
                            },
                            isSending = false,
                            statusLabel = null
                        )
                    }
                    is AskEvent.Error -> {
                        _uiState.value = _uiState.value.copy(
                            messages = _uiState.value.messages.map {
                                if (it.id == daisyPlaceholder.id)
                                    it.copy(text = event.message, isStreaming = false)
                                else it
                            },
                            isSending = false,
                            statusLabel = null
                        )
                    }
                }
            }
        }
    }
}
