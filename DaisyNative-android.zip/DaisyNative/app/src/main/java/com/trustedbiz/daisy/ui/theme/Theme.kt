package com.trustedbiz.daisy.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DaisyDark = darkColorScheme(
    primary = Color(0xFFD9C36A),
    background = Color(0xFF2B2B2B),
    surface = Color(0xFF333333)
)

private val DaisyLight = lightColorScheme(
    primary = Color(0xFF8A6D00),
    background = Color(0xFFFAFAFA),
    surface = Color(0xFFFFFFFF)
)

@Composable
fun DaisyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DaisyDark else DaisyLight
    MaterialTheme(colorScheme = colorScheme, content = content)
}
