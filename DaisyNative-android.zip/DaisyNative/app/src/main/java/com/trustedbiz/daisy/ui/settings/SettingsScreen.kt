package com.trustedbiz.daisy.ui.settings

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.trustedbiz.daisy.data.SettingsStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val settings = SettingsStore(application)

    var instructions by mutableStateOf("")
        private set
    var webSearchEnabled by mutableStateOf(true)
        private set

    init {
        viewModelScope.launch {
            instructions = settings.instructions.first()
            webSearchEnabled = settings.webSearchEnabled.first()
        }
    }

    fun onInstructionsChange(value: String) {
        instructions = value
        viewModelScope.launch { settings.setInstructions(value) }
    }

    fun onWebSearchToggle(value: Boolean) {
        webSearchEnabled = value
        viewModelScope.launch { settings.setWebSearchEnabled(value) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            Text("What should Daisy be to you?", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = viewModel.instructions,
                onValueChange = viewModel::onInstructionsChange,
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                placeholder = { Text("e.g. Be direct, skip the fluff…") }
            )

            Spacer(Modifier.height(24.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Search the internet", style = MaterialTheme.typography.titleMedium)
                Switch(checked = viewModel.webSearchEnabled, onCheckedChange = viewModel::onWebSearchToggle)
            }
        }
    }
}
