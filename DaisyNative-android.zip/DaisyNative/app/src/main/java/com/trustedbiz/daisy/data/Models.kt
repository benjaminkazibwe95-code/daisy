package com.trustedbiz.daisy.data

/** One turn in the conversation, shown in the chat list. */
data class ChatMessage(
    val id: String,
    val role: Role,
    val text: String,
    val sources: List<String> = emptyList(),
    val isStreaming: Boolean = false
)

enum class Role { USER, DAISY, STATUS }

/** Mirrors the {user, daisy, topic} shape the backend's /ask endpoint expects in "history". */
data class HistoryTurn(
    val user: String,
    val daisy: String,
    val topic: String = ""
)

/** A remembered personal fact — mirrors the client-side "memory" array the backend reads. */
data class MemoryFact(val text: String)
