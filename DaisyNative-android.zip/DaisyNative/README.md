# Daisy — Native Android App (Kotlin / Jetpack Compose)

A real native client for Daisy — no WebView, no TWA. It talks directly to
your existing Flask backend on Render (`daisy-qg1c.onrender.com`) using
the same `/ask` streaming endpoint the web app already uses.

## What's included
- **Chat screen** (Compose) — sends questions to `/ask`, streams the
  `"status"` → `"final"` NDJSON events live (shows "Thinking…" /
  "Searching the web…" while waiting), renders the answer + sources.
- **Settings screen** — persona instructions and the "search the
  internet" toggle, saved locally with DataStore and sent with every
  request, mirroring what the web app kept in `localStorage`.
- **Conversation memory** — the last 20 turns are kept in-session and
  sent back as `history` so Daisy has context, same shape as the web
  client (`{user, daisy, topic}`).
- Reuses your existing app icon (`icon-192.png` from the web project)
  and keeps the package name `com.trustedbiz.daisy`, so this can
  replace the old TWA APK on a device without conflicting.

## Not yet wired up (from the web app's feature set)
- Image attach → Claude vision (`/ask` already supports it; UI just
  doesn't have an image picker yet)
- Shared **Projects** (`/api/projects...`) — create/join/sync chats
  across devices
- PDF export (`/export/pdf`)
- Theme/accent picker, TTS

These are all straightforward additions once you confirm the chat core
works the way you want — happy to add any of them next.

## How to build
1. Open this folder in **Android Studio** (Iguana or newer).
2. Let Gradle sync — it will generate the wrapper automatically the
   first time (needs internet access on your machine, not this sandbox).
3. Run on a device/emulator, or **Build > Generate Signed Bundle/APK**
   to produce a release APK/AAB for the Play Store.

## If the backend URL ever changes
It's the single constructor default in
`app/src/main/java/com/trustedbiz/daisy/network/DaisyApi.kt`:

```kotlin
class DaisyApi(private val baseUrl: String = "https://daisy-qg1c.onrender.com")
```
